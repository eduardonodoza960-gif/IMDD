package com.imdd.reliquias;

import net.fabricmc.api.ClientModInitializer;

public class ImddReliquiasClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Renderização de invisibilidade total de armadura gerenciada via ArmorFeatureRendererMixin
    }
}
