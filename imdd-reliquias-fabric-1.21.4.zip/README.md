# IMDD Relíquias (Fabric 1.21.4)

Mod completo com as **20 Relíquias** no menu de 27 slots (`IMDD >> Relíquia`).

## Como usar no jogo
- Digite `/reliquias` (ou `/reliquia`) para abrir o baú com as 20 Relíquias.
- Clique em qualquer relíquia para pegá-la no inventário.

## Como compilar direto pelo GitHub (sem precisar instalar nada no PC)
1. Crie um repositório novo no GitHub.
2. Envie todos os arquivos deste `.zip` para o repositório.
3. Vá na aba **Actions** do repositório no GitHub.
4. Clique em **Build Fabric Mod** -> **Run workflow** (ou ele já roda automático assim que você enviar os arquivos).
5. Quando ficar verde, entre no build finalizado e baixe o artefato **`imdd-reliquias-1.21.4`** (dentro dele está o arquivo `.jar` pronto para colocar na pasta `mods` junto com o **Fabric API 1.21.4**).
